package cts.ionel.alexandru1103.singleton;

public interface ITestingModule {
//this method will return the result of the testing
	public String test();
}
