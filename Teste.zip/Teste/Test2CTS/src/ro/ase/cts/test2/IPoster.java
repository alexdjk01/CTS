package ro.ase.cts.test2;

public interface IPoster {

	public void print(IShow show);
	IPoster clone();
	
}
