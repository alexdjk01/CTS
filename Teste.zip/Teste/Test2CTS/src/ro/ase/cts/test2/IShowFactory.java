package ro.ase.cts.test2;

public interface IShowFactory {
	
	 IShow createShow(String name, String location, String date, String startingHour);

}
