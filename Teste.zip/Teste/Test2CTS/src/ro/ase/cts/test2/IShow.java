package ro.ase.cts.test2;

public interface IShow {

	public String getName();
	public String getLocation();
	public String getDateTime();
	
	public void printDetails();
	
}
